// Please don't steal my credentials !!! Unfortunately it is impossible to use variables and environment in Js vanilla 😞😥

(function() {
	emailjs.init("user_F1zjT6pQNovfefUOkGFC1")
})()