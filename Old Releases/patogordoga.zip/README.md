# Welcome to my portfolio 👋
![Version](https://img.shields.io/badge/version-1.4-blue.svg?cacheSeconds=2592000)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](#)
[![Twitter: Patogordoo](https://img.shields.io/twitter/follow/Patogordoo.svg?style=social)](https://twitter.com/Patogordoo)

> This is my portfolio, here I will show to you my skills, projects, a piece of my history as web developer, among other things.

### 🏠 [Homepage](https://patogordo.ga)

## Usage

```sh
Start 'index.html' in your browser.
```

## Author

👤 **PatoGordo**

* Website: [https://patogordo.ga](https://patogordo.ga)
* Twitter: [@Patogordoo](https://twitter.com/Patogordoo)
* Github: [@PatoGordo](https://github.com/PatoGordo)

## Show your support

Give a ⭐️ if this project helped you!


***
_This README was generated with ❤️ by [readme-md-generator](https://github.com/kefranabg/readme-md-generator)_
